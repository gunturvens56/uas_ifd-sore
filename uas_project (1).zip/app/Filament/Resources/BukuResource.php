<?php

// Dibuat oleh Guntur Valentino

namespace App\Filament\Resources;

use App\Filament\Resources\BukuResource\Pages;
use App\Models\Buku;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Table;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Filters\SelectFilter;

class BukuResource extends Resource
{
    protected static ?string $model = Buku::class;

    protected static ?string $navigationLabel = '📚 Data Buku';
    protected static ?string $navigationGroup = 'Manajemen Buku & Penjualan';
    protected static ?string $navigationIcon = 'heroicon-o-book-open';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Grid::make(2)->schema([
                Forms\Components\TextInput::make('judul')->required(),
                Forms\Components\TextInput::make('pengarang')->required(),
                Forms\Components\Select::make('kategori')
                    ->options([
                        'Fiksi' => 'Fiksi',
                        'Non Fiksi' => 'Non Fiksi',
                    ])
                    ->required(),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('judul')->searchable(),
                TextColumn::make('pengarang')->searchable(),
                BadgeColumn::make('kategori')
                    ->colors([
                        'primary' => 'Fiksi',
                        'success' => 'Non Fiksi',
                    ]),
                TextColumn::make('terjual')->label('Terjual'),
                TextColumn::make('penjualans_count')->label('Jumlah Transaksi'),
            ])
            ->filters([
                SelectFilter::make('kategori')->options([
                    'Fiksi' => 'Fiksi',
                    'Non Fiksi' => 'Non Fiksi',
                ])
            ])
            ->defaultSort('judul')
            ->heading('📘 Daftar Buku | Dibuat oleh Guntur Valentino');
    }

    public static function getEloquentQuery()
    {
        return parent::getEloquentQuery()->withCount('penjualans');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListBukus::route('/'),
            'create' => Pages\CreateBuku::route('/create'),
            'edit' => Pages\EditBuku::route('/{record}/edit'),
        ];
    }
}